def load_reminders() -> None:
    # Read the reminders for each task.
    pass
