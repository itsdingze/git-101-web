# Ticklist
A small to-do list app for learning Git.
Add your tasks to tasks.txt, one per line.
