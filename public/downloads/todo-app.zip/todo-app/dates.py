def read_due_dates() -> None:
    # Read each task's due date.
    # Skip finished tasks.
    pass
