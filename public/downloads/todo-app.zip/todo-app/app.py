def load_tasks() -> None:
    # Read tasks from tasks.txt.
    pass

def show_tasks() -> None:
    # Show only open tasks with reminders.
    pass

def show_due_dates() -> None:
    # Show each task's due date.
    pass

def show_search() -> None:
    # Show a search box.
    pass

def sort_by_priority() -> None:
    # Sort tasks by priority.
    pass

def sort_by_due_date() -> None:
    # Sort tasks by due date.
    pass

def show_export() -> None:
    # Show a button to export tasks.
    pass
