def find_tasks() -> None:
    # Find tasks matching the search.
    pass
