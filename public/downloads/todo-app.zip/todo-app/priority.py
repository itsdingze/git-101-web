def ask_priority() -> None:
    # Ask how important each task is.
    pass
